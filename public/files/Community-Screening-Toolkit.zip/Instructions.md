
# Community Screening Toolkit – Instructions

## 1. Purpose
This toolkit supports community eye screening activities for SEHA teams.

## 2. Included Tools
- Screening Register (Excel)
- Referral Form (PDF)
- Basic workflow instructions

## 3. Workflow
1. Register each patient using the Excel sheet.
2. Conduct visual acuity and basic screening.
3. Fill the referral form for any patient needing facility-level care.
4. Record follow-up appointments and notes.

## 4. Contacts
SEHA Program & M&E Team
